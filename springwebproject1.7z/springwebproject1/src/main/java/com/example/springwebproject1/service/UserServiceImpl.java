package com.example.springwebproject1.service;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.springwebproject1.dao.UserDao;
import com.example.springwebproject1.model.User;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserDao userdao;

	@Override
	public User registerUser(User user) throws SQLException {
		// TODO Auto-generated method stub
		
		userdao.save(user);
		return user;
		
	}

	@Override
	public List<User> findByUsername(String username) {
		// TODO Auto-generated method stub
        
        return userdao.findByUsername(username);

	}


}
