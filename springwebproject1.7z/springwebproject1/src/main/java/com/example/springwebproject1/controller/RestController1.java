/*package com.example.springwebproject1.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.example.springwebproject1.dao.CompanyDao;
import com.example.springwebproject1.dao.IPODao;
import com.example.springwebproject1.model.Company;
import com.example.springwebproject1.model.IPO_planned;

@RestController
public class RestController1 {
	
	@Autowired
	CompanyDao companydao;
	
	@Autowired
	IPODao ipodao;
	
	
	@GetMapping(value = "company/sectorId/{sectorId}")
	public List<Company> findBySectorId(@PathVariable int sectorId) {

	       List<Company> company = companydao.findBySectorId(sectorId);
	       return company;
	}

	@GetMapping(value = "/ipo/companyCode/{companyCode}")
	public IPO_planned findByCompanyCode(@PathVariable int companyCode)
	{
		 
		return ipodao.findByCompanyCode(companyCode);
	}
	
	

}*/
