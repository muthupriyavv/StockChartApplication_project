package com.example.springwebproject1.service;

import java.util.List;

import com.example.springwebproject1.model.StockExchange;

public interface StockExchangeService {
	
	public StockExchange insertStock(StockExchange stockexchange);
	public List<StockExchange> getStockList();

}
