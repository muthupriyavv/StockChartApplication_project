package com.example.springwebproject1.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.springwebproject1.dao.StockExchangeDao;
import com.example.springwebproject1.model.StockExchange;

@Service
public class StockExchangeServiceImpl  implements  StockExchangeService {
    
	@Autowired
	private StockExchangeDao  stockexchangedao;
	@Override
	public StockExchange insertStock(StockExchange stockexchange) {
		// TODO Auto-generated method stub
		stockexchangedao.save(stockexchange);
		return stockexchange;
	}
	@Override
	public List<StockExchange> getStockList() {
		// TODO Auto-generated method stub
		return stockexchangedao.findAll();
	}

}
