package com.example.springwebproject1.service;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.example.springwebproject1.dao.CompanyDao;
import com.example.springwebproject1.model.Company;



@Service("companyservice")
public class CompanyServiceImpl implements CompanyService {

	@Autowired
	private CompanyDao companyDao;
	
	@Override
	public Company insertCompany(Company company) throws SQLException {
		// TODO Auto-generated method stub
		// companyDao.insertCompany(company);
		companyDao.save(company);
		 return company ;
	}

	@Override
	public void updateCompany(Company company) {
		// TODO Auto-generated method stub
		
        System.out.println(company.getCompany_name());
        companyDao.save(company);
        
	}

	@Override
	public List<Company> getCompanyList() throws SQLException, ClassNotFoundException {
		return companyDao.findAll();
	}

	@Override
	public Company fetchStockUpdate(int companyId) throws SQLException, ClassNotFoundException {
		// TODO Auto-generated method stub
		return companyDao.getOne(companyId);
	}

}
