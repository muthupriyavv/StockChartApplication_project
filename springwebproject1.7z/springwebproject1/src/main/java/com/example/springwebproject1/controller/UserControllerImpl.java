package com.example.springwebproject1.controller;

import java.sql.SQLException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.example.springwebproject1.model.Company;
import com.example.springwebproject1.model.User;
import com.example.springwebproject1.service.UserService;

@Controller
public class UserControllerImpl{
    
	@Autowired
	private UserService userservice;
	
	@RequestMapping("/AdminLogin")
    public ModelAndView insertUser(ModelMap map) throws SQLException {
           ModelAndView mav = null;
           map.addAttribute("user", new User());
           
           mav = new ModelAndView("Admin_registration_page");
           return mav;

    }  
  
	@RequestMapping(value = "/Admin_registration_page", method = RequestMethod.POST)
    public ModelAndView registerUser( @ModelAttribute("user") @Valid User user, BindingResult result,
                  HttpServletRequest request, HttpSession session, ModelMap map) throws SQLException {
           ModelAndView mav = null;
           if (result.hasErrors()) {
                  mav = new ModelAndView("UserRegistration");
                  return mav;
           }
       userservice.registerUser(user);
       mav = new ModelAndView("redirect:/AdminLogin");
           return mav;

    }
	
	@RequestMapping(path= "/AdminLogin", method = RequestMethod.POST)
    public ModelAndView registerCompany( @ModelAttribute("user") @Valid User user, BindingResult result,
                  HttpServletRequest request, HttpSession session, ModelMap map) throws SQLException {

     ModelAndView mav = null;

     String username = user.getUsername();
     

     List<User> user1 = userservice.findByUsername(username);

     User user2 = user1.get(0);
     System.out.println(user.getUsername()+" "+user2.getUsername());
     
     System.out.println(user.getPassword()+" "+user2.getPassword());
     if ((user.getUsername().equals(user2.getUsername())) && (user.getPassword().equals(user2.getPassword()))) {

           
                  mav = new ModelAndView("AdminLandingPage");
            
     } 
     else {

            mav = new ModelAndView("login", "message", "Invalid Username or Password");
     }

     return mav;


    }
}


