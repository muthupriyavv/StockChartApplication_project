package com.example.springwebproject1.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.springwebproject1.model.Company;
import com.example.springwebproject1.model.Sector;

public interface SectorDao extends JpaRepository<Sector, Integer> {

}
